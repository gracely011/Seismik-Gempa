# Nerra.id Agentic Framework


> This configuration is universally compatible across AI environments (AGENTS.md, CLAUDE.md, GEMINI.md).


As an AI agent, you must navigate the gap between probabilistic LLM reasoning and the strict, deterministic logic required for real-world applications. To achieve maximum reliability, you will operate strictly under a 3-Tier Workflow.


## The 3-Tier Workflow


**Tier 1: The Blueprint (Directives)**
- Located in the `directives/` folder as Markdown files.
- These are your standard operating procedures (SOPs). They define your objectives, required inputs, authorized scripts, expected outputs, and how to handle edge cases.
- Treat these as clear, natural-language instructions from a human manager.


**Tier 2: The Brain (Orchestration)**
- This is your primary role: intelligent delegation and routing.
- You read the blueprints, trigger the right tools in the correct sequence, manage errors, request human input when stuck, and refine directives based on new findings.
- You are the bridge. Instead of executing complex tasks (like web scraping) directly, you parse the directive and trigger the corresponding script (e.g., `execution/web_scraper.py`).


**Tier 3: The Muscle (Execution)**
- Located in the `execution/` folder as Python scripts.
- These are deterministic, hard-coded tools.
- They handle API requests, file management, data crunching, and database queries.
- They must be fast, heavily commented, and reliable. All sensitive keys reside in `.env`.


*The Philosophy:* Relying solely on AI for multi-step execution causes compounding errors (e.g., 90% accuracy over 5 steps drops to 59% success rate). We solve this by offloading the actual "doing" to deterministic code, freeing you to focus entirely on "thinking" and decision-making.


## Core Rules of Engagement


**1. Search Before You Build**
Always check the `execution/` folder for existing scripts before writing new code. Avoid redundant tool creation.


**2. The Auto-Correction Protocol**
- When an error occurs, analyze the stack trace immediately.
- Fix the execution script and re-test it (unless it consumes paid API credits, in which case you must prompt the user first).
- If you hit constraints (e.g., rate limits), adapt the script, test it, and document the solution.


**3. Evolve the Blueprints**
Directives are living documents. Whenever you discover a better workflow, API limitation, or common bug, update the corresponding file in `directives/`. However, never overwrite or delete a directive entirely without explicit permission. Your instructions must be preserved and improved over time.


## File Organization & Architecture


**Output Types:**
- **Final Deliverables:** Cloud-based access points (Google Sheets, Slides, etc.) meant for the end-user.
- **Temporary Data:** Intermediary files used during operations.


**Directory Map:**
- `.tmp/` - Disposable data (scraped text, temp JSONs). Safe to delete and recreate.
- `execution/` - The deterministic Python scripts.
- `directives/` - Your Markdown instruction manuals.
- `.env` - Environment variables (strictly local).
- `credentials.json` / `token.json` - Auth files (must remain in `.gitignore`).


## System Summary
Your job is to bridge human intent with code execution. Read the blueprints, make smart routing decisions, run the deterministic tools, catch your own errors, and constantly optimize the workflow. Be reliable, practical, and self-correcting.# Custom Workspace Rules (svgdesigncode2)

The rules in this file apply specifically to this workspace. They extend the global AGENTS.md rules.

## Core Directives

### 1. Mandatory Task Logging
- **Rule**: EVERY TIME you complete a command/task from the user, you MUST write a log entry summarizing what you did before ending your turn.
- **Location**: Write the log in the `logs/` directory at the root of this workspace.
- **Filename Format**: `logs/YYYY-MM-DD_session.md`. If the file already exists for today, APPEND the new log entry to it.
- **Content Requirements**:
  - The precise time (HH:MM:SS) the task was started and finished.
  - A brief description of the objective.
  - A detailed list of files modified and the specific changes made.
  - The final status (Success/Failed) and any important notes.
- **Purpose**: This ensures a complete, timestamped history of all modifications, allowing the user to issue a "rollback to previous session" command if an error occurs.

### 2. Rollback Protocol
- **Rule**: If the user requests to "rollback" or "undo" to a previous state due to an error, you MUST first read the logs in the `logs/` directory to understand exactly what files were modified in the previous session(s), and then systematically revert those changes to restore the application's prior working state.

### 4. Language Requirement
- **Rule**: Every Implementation Plan generated (e.g. implementation_plan.md) and all subsequent technical communication related to the implementation plan MUST ALWAYS be written in Indonesian (Bahasa Indonesia).

### 5. Auto-Update CodeGraph
- **Rule**: Every time the user initiates a new session (e.g., by saying "start"), you MUST automatically check for and install the latest version of CodeGraph by running `npm install -g @statelyai/codegraph@latest` in the background. This ensures the MCP server is always up-to-date.

### 6. Standar Penggunaan Ikon Vektor (Google Material Symbols SVG)
- **Rule**: Setiap kali menambahkan atau memodifikasi ikon di dalam proyek ini, Anda WAJIB SELALU menggunakan kode vektor **Inline SVG resmi dari Google Material Symbols / Material Design Icons** (`viewBox="0 0 24 24"`, `fill="currentColor"`).
- **Larangan**: JANGAN PERNAH menggunakan web font Material Symbols (Google Font CDN) karena menyebabkan FOUT (teks nama icon bocor sebelum font ter-download) dan membebani kuota pengguna.
